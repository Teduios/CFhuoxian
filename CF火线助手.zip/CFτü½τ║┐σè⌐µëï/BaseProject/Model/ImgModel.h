//
//  ImgModel.h
//  BaseProject
//
//  Created by mis on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@class ImgPicModel,ImgPicListModel,ImgPicListBackup3Model,ImgChannelModel;
@interface ImgModel : BaseModel

@property (nonatomic, strong) NSArray<ImgChannelModel *> *channel;

@property (nonatomic, strong) ImgPicModel *pic;

@end
@interface ImgPicModel : NSObject

@property (nonatomic, assign) BOOL next_page;

@property (nonatomic, strong) NSArray<ImgPicListModel *> *list;

@end

@interface ImgPicListModel : NSObject

@property (nonatomic, copy) NSString *ID;

@property (nonatomic, strong) ImgPicListBackup3Model *backup3;

@property (nonatomic, copy) NSString *backup2;

@property (nonatomic, copy) NSString *comment_info;

@property (nonatomic, copy) NSString *type;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *img_url;

@property (nonatomic, copy) NSString *channel_id;

@property (nonatomic, copy) NSString *img_width;

@property (nonatomic, copy) NSString *backup1;

@property (nonatomic, copy) NSString *img_height;

@property (nonatomic, copy) NSString *img_desc;

@property (nonatomic, copy) NSString *direct_url;

@end

@interface ImgPicListBackup3Model : NSObject

@property (nonatomic, copy) NSString *picId;

@end

@interface ImgChannelModel : NSObject

@property (nonatomic, copy) NSString *id;

@property (nonatomic, copy) NSString *name;

@property (nonatomic, copy) NSString *img_url;

@end

