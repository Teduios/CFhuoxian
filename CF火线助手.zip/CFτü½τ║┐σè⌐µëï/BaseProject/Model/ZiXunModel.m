//
//  ZiXunModel.m
//  BaseProject
//
//  Created by tarena on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ZiXunModel.h"

@implementation ZiXunModel

+ (NSDictionary *)objectClassInArray{
    return @{@"ads":[ZiXunAdsModel class],@"news":[ZiXunNewsModel class]};
}
+(NSString *)replacedKeyFromPropertyName121:(NSString *)propertyName{
    return [propertyName underlineFromCamel];
}
@end

@implementation ZiXunAdsModel

+(NSString *)replacedKeyFromPropertyName121:(NSString *)propertyName{
    return [propertyName underlineFromCamel];
}

@end

@implementation ZiXunNewsModel

+(NSString *)replacedKeyFromPropertyName121:(NSString *)propertyName{
    return [propertyName underlineFromCamel];
}
@end

@implementation ZiXunAdsBackup1Model

+(NSDictionary *)replacedKeyFromPropertyName{
    return @{@"Id":@"id"};
}

@end

@implementation ZiXunAdsBackup3Model



@end
