//
//  ZiXunModel.h
//  BaseProject
//
//  Created by tarena on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@class ZiXunAdsModel,ZiXunNewsModel,ZiXunAdsBackup1Model,ZiXunAdsBackup3Model;
@interface ZiXunModel : BaseModel

@property (nonatomic,strong) NSArray<ZiXunAdsModel *> *ads;
@property (nonatomic,strong) NSArray<ZiXunNewsModel *> *news;
@property (nonatomic) BOOL nextPage;

@end


@interface ZiXunAdsModel : BaseModel

@property (nonatomic,strong) NSString *actBeginDate;
@property (nonatomic,strong) NSString *actEndDate;
@property (nonatomic,strong) NSString *articleType;
@property (nonatomic,strong) ZiXunAdsBackup1Model *backup1;
@property (nonatomic,strong) ZiXunAdsBackup3Model *backup3;
@property (nonatomic,strong) NSString *commentInfo;
@property (nonatomic,strong) NSString *Id;
@property (nonatomic,strong) NSString *imageUrl;
@property (nonatomic,strong) NSString *publicationDate;
@property (nonatomic,strong) NSString *subscript;
@property (nonatomic,strong) NSString *summary;
@property (nonatomic,strong) NSString *title;
@property (nonatomic,strong) NSString *type;
@property (nonatomic,strong) NSString *url;


@end
@interface ZiXunNewsModel : BaseModel
@property (nonatomic,strong) NSString *actBeginDate;
@property (nonatomic,strong) NSString *actEndDate;
@property (nonatomic,strong) NSString *articleType;
@property (nonatomic,strong) ZiXunAdsBackup1Model *backup1;
@property (nonatomic,strong) ZiXunAdsBackup3Model *backup3;
@property (nonatomic,strong) NSString *commentInfo;
@property (nonatomic,strong) NSString *Id;
@property (nonatomic,strong) NSString *imageUrl;
@property (nonatomic) NSInteger isTop;
@property (nonatomic,strong) NSString *publicationDate;
@property (nonatomic,strong) NSString *subscript;
@property (nonatomic,strong) NSString *summary;
@property (nonatomic,strong) NSString *title;
@property (nonatomic,strong) NSString *type;
@property (nonatomic,strong) NSString *url;
@property (nonatomic,strong) NSArray *listImageUrl;
@end


@interface ZiXunAdsBackup1Model : BaseModel
@property (nonatomic) BOOL comment;
@end

@interface ZiXunAdsBackup3Model : BaseModel
@property (nonatomic,strong) NSString *vid;
@property (nonatomic,strong) NSString *videoType;
@property (nonatomic,strong) NSString *videoUrl;
@end