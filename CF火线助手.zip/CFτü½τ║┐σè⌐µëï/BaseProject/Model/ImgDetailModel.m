//
//  ImgDetailModel.m
//  BaseProject
//
//  Created by tarena on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ImgDetailModel.h"

@implementation ImgDetailModel


+ (NSDictionary *)objectClassInArray{
    return @{@"list" : [ImgDetailListModel class]};
}
@end
@implementation ImgDetailListModel
+ (NSDictionary *)replacedKeyFromPropertyName{
    return @{@"ID":@"id"};
}
@end


