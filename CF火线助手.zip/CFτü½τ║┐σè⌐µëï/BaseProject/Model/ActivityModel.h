//
//  ActivityModel.h
//  BaseProject
//
//  Created by mis on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"


@class ActivityAdsModel,ActivityNewsModel,ActivityNewsBackup1Model,ActivityNewsBackup3Model;
@interface ActivityModel : BaseModel
@property (nonatomic,strong) NSArray<ActivityAdsModel *> *ads;
@property (nonatomic,strong) NSArray<ActivityNewsModel *> *news;
@property (nonatomic) BOOL nextPage;
@end

@interface ActivityAdsModel : BaseModel

@end

@interface ActivityNewsModel : BaseModel
@property (nonatomic,strong) NSString *actBeginDate;
@property (nonatomic,strong) NSString *actEndDate;
@property (nonatomic,strong) NSString *articleType;
@property (nonatomic,strong) ActivityNewsBackup1Model *backup1;
@property (nonatomic,strong) ActivityNewsBackup3Model *backup3;
@property (nonatomic,strong) NSString *commentInfo;
@property (nonatomic,strong) NSString *Id;
@property (nonatomic,strong) NSString *imageUrl;
@property (nonatomic) NSInteger isTop;
@property (nonatomic,strong) NSString *publicationDate;
@property (nonatomic,strong) NSString *subscript;
@property (nonatomic,strong) NSString *summary;
@property (nonatomic,strong) NSString *title;
@property (nonatomic,strong) NSString *type;
@property (nonatomic,strong) NSString *url;

@end

@interface ActivityNewsBackup1Model : BaseModel
@property (nonatomic) BOOL comment;
@end

@interface ActivityNewsBackup3Model : BaseModel
@property (nonatomic,strong)NSString *joinType;
@end
