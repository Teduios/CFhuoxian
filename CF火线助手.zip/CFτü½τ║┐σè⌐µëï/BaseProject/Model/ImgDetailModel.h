//
//  ImgDetailModel.h
//  BaseProject
//
//  Created by tarena on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@class ImgDetailListModel;
@interface ImgDetailModel : BaseModel

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *image_url;

@property (nonatomic, strong) NSArray<ImgDetailListModel *> *list;

@property (nonatomic, copy) NSString *share_url;

@property (nonatomic, copy) NSString *summary;

@end
@interface ImgDetailListModel : NSObject

@property (nonatomic, copy) NSString *ID;

@property (nonatomic, copy) NSString *pic_id;

@property (nonatomic, copy) NSString *img_desc;

@property (nonatomic, copy) NSString *img_url;

@end

