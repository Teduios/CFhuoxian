//
//  VideoModel.h
//  BaseProject
//
//  Created by mis on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@class VideoDataModel,VideoDataItemsModel,VideoDataItemsChannelModel,VideoDataItemsGameModel;
@interface VideoModel : BaseModel

@property (nonatomic,strong)NSString *apiVersion;
@property (nonatomic,strong)VideoDataModel *data;
@property (nonatomic,strong)NSString *lastupdate;

@end

@interface VideoDataModel : BaseModel

@property (nonatomic,strong)NSArray<VideoDataItemsModel *> *items;
@property (nonatomic)NSInteger limit;
@property (nonatomic)NSInteger offset;
@property (nonatomic,strong)NSString *sort;
@property (nonatomic)NSInteger  totalItems;

@end

@interface VideoDataItemsModel : BaseModel
@property (nonatomic,strong)VideoDataItemsChannelModel *channel;
@property (nonatomic,strong)NSArray<VideoDataItemsGameModel *> *game;
@property (nonatomic,strong)NSString *preview;
@property (nonatomic,strong)NSString *viewers;

@end

@interface VideoDataItemsChannelModel : BaseModel
@property (nonatomic,strong)NSString *Subtype;
@property (nonatomic,strong)NSString *Type;
@property (nonatomic,strong)NSString *avatar;
@property (nonatomic,strong)NSString *belle;
@property (nonatomic)NSInteger broadcastBegin;
@property (nonatomic,strong)NSString *broadcastDuration;
@property (nonatomic,strong)NSString *domain;
@property (nonatomic,strong)NSString *flowers;
@property (nonatomic,strong)NSString *followers;
@property (nonatomic,strong)NSString *glamours;
@property (nonatomic)NSInteger grade;
@property (nonatomic,strong)NSString *ID;
@property (nonatomic,strong)NSString *name;
@property (nonatomic,strong)NSString *status;
@property (nonatomic,strong)NSString *tag;
@property (nonatomic,strong)NSString *url;
@property (nonatomic)NSInteger vid;
@property (nonatomic,strong)NSString *videos;
@property (nonatomic)NSInteger weight;
@end

@interface VideoDataItemsGameModel : BaseModel
@property (nonatomic,strong)NSString *ID;
@property (nonatomic,strong)NSString *Id;
@property (nonatomic,strong)NSString *Name;
@property (nonatomic,strong)NSString *name;
@property (nonatomic,strong)NSString *tag;
@end