//
//  VideoModel.m
//  BaseProject
//
//  Created by mis on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "VideoModel.h"

@implementation VideoModel

@end

@implementation VideoDataModel

+(NSDictionary *)objectClassInArray{
    return @{@"items":[VideoDataItemsModel class]};
}

@end

@implementation VideoDataItemsModel

+(NSDictionary *)objectClassInArray{
    return @{@"game":[VideoDataItemsGameModel class]};
}

@end

@implementation VideoDataItemsGameModel

+(NSDictionary *)replacedKeyFromPropertyName{
    return @{@"ID":@"id"};
}

@end

@implementation VideoDataItemsChannelModel

+(NSDictionary *)replacedKeyFromPropertyName{
    return @{@"ID":@"id"};
}
+(NSString *)replacedKeyFromPropertyName121:(NSString *)propertyName{
    return [propertyName underlineFromCamel];
}

@end