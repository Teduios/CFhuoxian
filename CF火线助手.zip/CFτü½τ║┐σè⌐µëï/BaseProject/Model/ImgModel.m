//
//  ImgModel.m
//  BaseProject
//
//  Created by mis on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ImgModel.h"

@implementation ImgModel


+ (NSDictionary *)objectClassInArray{
    return @{@"channel" : [ImgChannelModel class]};
}
@end
@implementation ImgPicModel

+ (NSDictionary *)objectClassInArray{
    return @{@"list" : [ImgPicListModel class]};
}

@end


@implementation ImgPicListModel
+ (NSDictionary *)replacedKeyFromPropertyName{
    return @{@"ID":@"id"};
}
@end


@implementation ImgPicListBackup3Model

@end


@implementation ImgChannelModel

@end


