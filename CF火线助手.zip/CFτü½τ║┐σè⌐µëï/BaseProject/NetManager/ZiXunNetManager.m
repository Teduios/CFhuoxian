//
//  ZiXunNetManager.m
//  BaseProject
//
//  Created by tarena on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ZiXunNetManager.h"

@implementation ZiXunNetManager

+(id)getZiXunModelWithPage:(NSInteger)page completionHandle:(void(^)(ZiXunModel *model,NSError *error))completionHandle{
    NSString *path = [NSString stringWithFormat:@"http://qt.qq.com/php_cgi/cf_news/php/varcache_getnews.php?id=8&page=%ld&channel=ios&version=9641",page];
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([ZiXunModel objectWithKeyValues:responseObj],error);
    }];
}

@end
