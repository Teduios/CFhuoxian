//
//  ImgNetManager.m
//  BaseProject
//
//  Created by tarena on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ImgNetManager.h"
#import "ImgModel.h"
@implementation ImgNetManager
+ (id)getImgListWithPage:(NSInteger)page AndChannelId:(NSInteger)channelId kCompletionHandle{
    NSString *path = [NSString stringWithFormat:@"http://qt.qq.com/php_cgi/cf_news/php/varcache_getpic.php?channel=%ld&device=ios&page=%ld&pagenum=10&version=9641",channelId,page];
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([ImgModel objectWithKeyValues:responseObj],error);
    }];
}
@end
