//
//  ImgDetailNetManager.m
//  BaseProject
//
//  Created by tarena on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ImgDetailNetManager.h"
#import "ImgDetailModel.h"
@implementation ImgDetailNetManager
+ (id)getImgDetailListWithId:(NSInteger)Id completionHandle:(void (^)(id, NSError *))completionHandle{
    NSString *path = [NSString stringWithFormat:@"http://qt.qq.com/php_cgi/cf_news/php/varcache_getpic_article.php?id=%ld&version=9641&device=ios",Id];
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([ImgDetailModel objectWithKeyValues:responseObj],error);
    }];
}
@end
