//
//  ActivityNetManager.m
//  BaseProject
//
//  Created by tarena on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ActivityNetManager.h"

@implementation ActivityNetManager

+(id)getActivityModelWithPage:(NSInteger)page completionHandel:(void(^)(ActivityModel *model,NSError *error))completionHandle{
    NSString *path = [NSString stringWithFormat:@"http://qt.qq.com/php_cgi/cf_news/php/varcache_getnews.php?id=15&page=%ld&channel=ios&version=9641",page];
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([ActivityModel objectWithKeyValues:responseObj],error);
    }];
}

@end
