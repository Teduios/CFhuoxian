//
//  ImgDetailNetManager.h
//  BaseProject
//
//  Created by tarena on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"

@interface ImgDetailNetManager : BaseNetManager
+ (id)getImgDetailListWithId:(NSInteger)Id kCompletionHandle;
@end
