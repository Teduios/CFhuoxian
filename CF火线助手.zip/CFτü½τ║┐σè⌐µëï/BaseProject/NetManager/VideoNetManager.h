//
//  VideoNetManager.h
//  BaseProject
//
//  Created by tarena on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "VideoModel.h"

@interface VideoNetManager : BaseNetManager

+(id)getVideoModelWithCompletionHandle:(void(^)(VideoModel *model,NSError *error))completionHandle;

@end
