//
//  VideoNetManager.m
//  BaseProject
//
//  Created by tarena on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "VideoNetManager.h"

@implementation VideoNetManager
+(id)getVideoModelWithCompletionHandle:(void(^)(VideoModel *model,NSError *error))completionHandle{
    NSString *path = @"http://api.plu.cn/tga/streams?sort-by=top&game=7&max-results=100";
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([VideoModel objectWithKeyValues:responseObj],error);
    }];
}
@end
