//
//  ActivityNetManager.h
//  BaseProject
//
//  Created by tarena on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "ActivityModel.h"

@interface ActivityNetManager : BaseNetManager

+(id)getActivityModelWithPage:(NSInteger)page completionHandel:(void(^)(ActivityModel *model,NSError *error))completionHandle;


@end
