//
//  ActivityViewModel.h
//  BaseProject
//
//  Created by tarena on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "ActivityNetManager.h"

@interface ActivityViewModel : BaseViewModel

@property (nonatomic) NSInteger rowNumber;
@property (nonatomic) NSInteger page;

- (NSURL *)imgURLForRow:(NSInteger)row;
- (NSString *)titleForRow:(NSInteger)row;
- (NSString *)summaryForRow:(NSInteger)row;

- (NSString *)dateForRow:(NSInteger)row;
- (NSString *)subscriptForRow:(NSInteger)row;
- (CGFloat)valueForRow:(NSInteger)row;

- (NSURL *)urlForRow:(NSInteger)row;

-(BOOL)pcreedForRow:(NSInteger)row;

@end
