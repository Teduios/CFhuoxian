//
//  ZiXunViewModel.m
//  BaseProject
//
//  Created by tarena on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ZiXunViewModel.h"
#import "ZiXunNetManager.h"

@implementation ZiXunViewModel

-(NSMutableArray *)headArr{
    if (!_headArr) {
        _headArr = [NSMutableArray new];
    }
    return _headArr;
}

-(NSInteger)rowNumber{
    return self.dataArr.count;
}
-(NSInteger)count{
    return self.headArr.count;
}
-(void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
    self.dataTask = [ZiXunNetManager getZiXunModelWithPage:_page completionHandle:^(ZiXunModel *model, NSError *error) {
        if (_page == 1) {
            [self.dataArr removeAllObjects];
            self.headArr = [model.ads copy];
        }
        [self.dataArr addObjectsFromArray:model.news];
        
        completionHandle(error);
    }];
}

-(void)refreshDataCompletionHandle:(CompletionHandle)completionHandle{
    _page = 1;
    [self getDataFromNetCompleteHandle:completionHandle];
}
-(void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle{
    _page += 1;
    [self getDataFromNetCompleteHandle:completionHandle];
}

- (ZiXunNewsModel *)modelForRow:(NSInteger)row{
    return self.dataArr[row];
}
- (ZiXunAdsModel *)headModelForRow:(NSInteger)row{
    return self.headArr[row];
}
-(NSString *)titleForRow:(NSInteger)row{
    return [self modelForRow:row].title;
}
-(NSString *)headertitleForRow:(NSInteger)row{
    return [self headModelForRow:row].title;
}
-(NSURL *)imgForrow:(NSInteger)row{
    return [NSURL URLWithString:[self modelForRow:row].imageUrl];
}
- (NSURL *)headerimgForRow:(NSInteger)row{
    return [NSURL URLWithString:[self headModelForRow:row].imageUrl];
}
-(NSURL *)urlForRow:(NSInteger)row{
    return [NSURL URLWithString:[self modelForRow:row].url];
}
-(NSURL *)headUrlForRow:(NSInteger)row{
    return [NSURL URLWithString:[self headModelForRow:row].url];
}
-(NSString *)summaryRowRow:(NSInteger)row{
    return [self modelForRow:row].summary;
}
-(NSString *)dateForRow:(NSInteger)row{
    NSString *date = [self modelForRow:row].publicationDate;
    NSArray *arr = [[date componentsSeparatedByString:@" "].firstObject componentsSeparatedByString:@"-"];
    return [[arr[1] stringByAppendingString:@"-"] stringByAppendingString:arr[2]];
}

-(BOOL)listImgUrlForRow:(NSInteger)row{
    return [[self modelForRow:row].articleType isEqualToString:@"3"];
}
-(NSArray *)listImgForRow:(NSInteger)row{
    NSMutableArray *imgArr = [NSMutableArray new];
    
        for (int i = 0; i < [self modelForRow:row].listImageUrl.count; i ++) {
            NSURL *imgURL = [NSURL URLWithString:[self modelForRow:row].listImageUrl[i]];
            [imgArr addObject:imgURL];
        }
        return [imgArr copy];
    }

@end
