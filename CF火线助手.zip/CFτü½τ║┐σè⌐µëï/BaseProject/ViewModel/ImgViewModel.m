//
//  ImgViewModel.m
//  BaseProject
//
//  Created by tarena on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ImgViewModel.h"
#import "ImgNetManager.h"
#import "ImgModel.h"
@implementation ImgViewModel
- (instancetype)initWithChannelId:(NSInteger)channelId{
    if (self = [super init]) {
        self.channelId = channelId;
    }
    return self;
}
- (NSInteger)rowNumber{
    return self.dataArr.count;
}
- (void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
    [ImgNetManager getImgListWithPage:_page AndChannelId:_channelId completionHandle:^(ImgModel *model, NSError *error) {
        [self.dataArr addObjectsFromArray:model.pic.list];
        completionHandle(error);
    }];
}
- (void)refreshDataCompletionHandle:(CompletionHandle)completionHandle{
    _page = 1;
    [self getDataFromNetCompleteHandle:completionHandle];
}
- (void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle{
    _page += 1;
    [self getDataFromNetCompleteHandle:completionHandle];
}
- (ImgPicListModel *)listForRow:(NSInteger)row{
    return self.dataArr[row];
}
- (NSURL *)iconURLForRow:(NSInteger)row{
    return [NSURL URLWithString:[self listForRow:row].img_url];
}
- (NSString *)titleForRow:(NSInteger)row{
    return [self listForRow:row].title;
}
- (NSString *)descForRow:(NSInteger)row{
    return [self listForRow:row].img_desc;
}
- (NSInteger)imgIdForRow:(NSInteger)row{
    return [self listForRow:row].ID.integerValue;
}
- (BOOL)isManHuaTypeForRow:(NSInteger)row{
    return [[self listForRow:row].type isEqualToString:@"5"];
}
@end
