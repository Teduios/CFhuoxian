//
//  ImgViewModel.h
//  BaseProject
//
//  Created by tarena on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"

@interface ImgViewModel : BaseViewModel
@property (nonatomic) NSInteger rowNumber;
- (instancetype)initWithChannelId:(NSInteger)channelId;
@property (nonatomic) NSInteger page;
@property (nonatomic) NSInteger channelId;
- (NSURL *)iconURLForRow:(NSInteger)row;
- (NSString *)titleForRow:(NSInteger)row;
- (NSString *)descForRow:(NSInteger)row;
- (NSInteger)imgIdForRow:(NSInteger)row;
- (BOOL)isManHuaTypeForRow:(NSInteger)row;
@end
