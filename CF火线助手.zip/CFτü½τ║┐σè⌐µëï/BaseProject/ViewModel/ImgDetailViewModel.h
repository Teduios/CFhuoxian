//
//  ImgDetailViewModel.h
//  BaseProject
//
//  Created by tarena on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"

@interface ImgDetailViewModel : BaseViewModel
- (instancetype)initWithId:(NSInteger)Id;
@property (nonatomic) NSInteger Id;
@property (nonatomic) NSInteger rowNumber;
- (NSURL *)iconURLForRow:(NSInteger)row;
- (NSString *)descForRow:(NSInteger)row;
@end
