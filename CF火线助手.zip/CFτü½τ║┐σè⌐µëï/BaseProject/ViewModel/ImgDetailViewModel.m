//
//  ImgDetailViewModel.m
//  BaseProject
//
//  Created by tarena on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ImgDetailViewModel.h"
#import "ImgDetailNetManager.h"
#import "ImgDetailModel.h"
@implementation ImgDetailViewModel
- (NSInteger)rowNumber{
    return self.dataArr.count;
}
- (instancetype)initWithId:(NSInteger)Id{
    if (self = [super init]) {
        self.Id = Id;
    }
    return self;
}
- (void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
    [ImgDetailNetManager getImgDetailListWithId:_Id completionHandle:^(ImgDetailModel *model, NSError *error) {
        [self.dataArr addObjectsFromArray:model.list];
        completionHandle(error);
    }];
}
- (ImgDetailListModel *)modelForRow:(NSInteger)row{
    return self.dataArr[row];
}
- (NSURL *)iconURLForRow:(NSInteger)row{
    return [NSURL URLWithString:[self modelForRow:row].img_url];
}
- (NSString *)descForRow:(NSInteger)row{
    return [self modelForRow:row].img_desc;
}
@end

