//
//  ZiXunViewModel.h
//  BaseProject
//
//  Created by tarena on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"

@interface ZiXunViewModel : BaseViewModel

@property (nonatomic) NSInteger rowNumber;
@property (nonatomic) NSInteger count;
@property (nonatomic) NSInteger page;
@property (nonatomic,strong) NSMutableArray *headArr;

- (NSString *)headertitleForRow:(NSInteger)row;
- (NSString *)titleForRow:(NSInteger)row;

- (NSURL *)headerimgForRow:(NSInteger)row;
- (NSURL *)imgForrow:(NSInteger)row;
- (NSURL *)headUrlForRow:(NSInteger)row;
- (NSURL *)urlForRow:(NSInteger)row;
- (NSString *)dateForRow:(NSInteger)row;
- (NSString *)summaryRowRow:(NSInteger)row;

- (BOOL)listImgUrlForRow:(NSInteger)row;
- (NSArray *)listImgForRow:(NSInteger)row;
@end
