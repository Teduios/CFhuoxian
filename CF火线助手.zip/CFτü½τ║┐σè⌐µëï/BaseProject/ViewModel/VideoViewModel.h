//
//  VideoViewModel.h
//  BaseProject
//
//  Created by tarena on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "VideoViewModel.h"

@interface VideoViewModel : BaseViewModel

@property (nonatomic) NSInteger rowNumber;

- (NSURL *)previewForRow:(NSInteger)row;
- (NSString *)viewersForRow:(NSInteger)row;
- (NSString *)nameForRow:(NSInteger)row;
- (NSString *)statusForRow:(NSInteger)row;
- (NSURL *)urlForRow:(NSInteger)row;

@end
