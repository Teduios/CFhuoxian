//
//  ActivityViewModel.m
//  BaseProject
//
//  Created by tarena on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ActivityViewModel.h"
#import "ActivityNetManager.h"

@implementation ActivityViewModel

-(NSInteger)rowNumber{
    return self.dataArr.count;
}


-(void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
    self.dataTask = [ActivityNetManager getActivityModelWithPage:_page completionHandel:^(ActivityModel *model, NSError *error) {
        if (!error) {
            if (_page == 1) {
                [self.dataArr removeAllObjects];
            }
            [self.dataArr addObjectsFromArray:model.news];
        }
        completionHandle(error);
    }];
}
-(void)refreshDataCompletionHandle:(CompletionHandle)completionHandle{
    _page = 1;
    [self getDataFromNetCompleteHandle:completionHandle];
}
-(void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle{
    _page += 1;
    [self getDataFromNetCompleteHandle:completionHandle];
}

- (ActivityNewsModel *)modelForRow:(NSInteger)row{
    return self.dataArr[row];
}

-(NSURL *)imgURLForRow:(NSInteger)row{
    return [NSURL URLWithString:[self modelForRow:row].imageUrl];
}
-(NSString *)titleForRow:(NSInteger)row{
    return [self modelForRow:row].title;
}
-(NSString *)summaryForRow:(NSInteger)row{
    return [self modelForRow:row].summary;
}
-(NSString *)subscriptForRow:(NSInteger)row{
    return [self modelForRow:row].subscript;
}
-(NSString *)dateForRow:(NSInteger)row{
    NSString *begin = [self modelForRow:row].actBeginDate;
    NSString *end = [self modelForRow:row].actEndDate;
    NSString *beginStr = [begin componentsSeparatedByString:@" "].firstObject;
    NSString *endStr = [end componentsSeparatedByString:@" "].firstObject;
    return [NSString stringWithFormat:@"(%@~%@)",beginStr,endStr];
}

-(BOOL)pcreedForRow:(NSInteger)row{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSTimeZone *timeZone = [NSTimeZone timeZoneWithName:@"GMT"];
    [dateFormatter setTimeZone:timeZone];
    
    NSString *someDayStr = [self modelForRow:row].actEndDate;
    NSDate *someDayDate = [dateFormatter dateFromString:someDayStr];
    
    NSDate *currentDate = [NSDate date];
    NSTimeInterval time = [currentDate timeIntervalSinceDate:someDayDate];
    
    if (time > 0) {
        return YES;
    }else{
        return NO;
    }
}

- (NSURL *)urlForRow:(NSInteger)row{
    return [NSURL URLWithString:[self modelForRow:row].url];
}

-(CGFloat)valueForRow:(NSInteger)row{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSTimeZone *timeZone = [NSTimeZone timeZoneWithName:@"GMT"];
    [dateFormatter setTimeZone:timeZone];
    
    NSString *someDayStr = [self modelForRow:row].actBeginDate;
    NSDate *someDayDate = [dateFormatter dateFromString:someDayStr];
    
    NSString *otherDayStr = [self modelForRow:row].actEndDate;
    NSDate *otherDayDate = [dateFormatter dateFromString:otherDayStr];
    
    NSDate *currentDate = [NSDate date];
    NSTimeInterval time = [currentDate timeIntervalSinceDate:someDayDate];
    NSTimeInterval totaltime = [otherDayDate timeIntervalSinceDate:someDayDate];
    
    
    return time/totaltime;
}


@end
