//
//  VideoViewModel.m
//  BaseProject
//
//  Created by tarena on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "VideoViewModel.h"
#import "VideoNetManager.h"

@implementation VideoViewModel

-(NSInteger)rowNumber{
    return self.dataArr.count;
}

-(void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
    self.dataTask = [VideoNetManager getVideoModelWithCompletionHandle:^(VideoModel *model, NSError *error) {
        [self.dataArr addObjectsFromArray: model.data.items];
        completionHandle(error);
    }];
}

- (VideoDataItemsModel *)modelForRow:(NSInteger)row{
    return self.dataArr[row];
}
-(NSURL *)previewForRow:(NSInteger)row{
    return [NSURL URLWithString:[self modelForRow:row].preview];
}
-(NSString *)viewersForRow:(NSInteger)row{
    CGFloat views = [self modelForRow:row].viewers.floatValue;
    if (views >= 1000) {
        return [NSString stringWithFormat:@"%.2f万",views/10000.0];
    }else{
        return [NSString stringWithFormat:@"%.f",views];
    }
    
}
-(NSString *)nameForRow:(NSInteger)row{
    return [self modelForRow:row].channel.name;
}
-(NSString *)statusForRow:(NSInteger)row{
    return [self modelForRow:row].channel.status;
}
-(NSURL *)urlForRow:(NSInteger)row{
    return [NSURL URLWithString:[self modelForRow:row].channel.url];
}

@end
