//
//  CFTabBarController.m
//  BaseProject
//
//  Created by tarena on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "CFTabBarController.h"
#import "ZiXunViewController.h"
#import "VideoViewController.h"
#import "ImageViewController.h"
#import "ActivityViewController.h"

@interface CFTabBarController ()

@end

@implementation CFTabBarController



- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.tabBar.translucent = NO;
    self.tabBar.tintColor = [UIColor whiteColor];
    UIImage *background = [[UIImage imageNamed:@"playing_toolbar_bg"] resizableImageWithCapInsets:UIEdgeInsetsMake(10, 10, 10, 10) resizingMode:UIImageResizingModeStretch];
    [self.tabBar setBackgroundImage:background];
    UIImage *backgroundSelect = [[UIImage imageNamed:@""]  resizableImageWithCapInsets:UIEdgeInsetsMake(10, 10, 10, 10) resizingMode:UIImageResizingModeStretch];
    [self.tabBar setSelectionIndicatorImage:backgroundSelect];
    ZiXunViewController *zixunVC = [[ZiXunViewController alloc]init];
    VideoViewController *videoVC = [[VideoViewController alloc]init];
    ImageViewController *imageVC = [[ImageViewController alloc]initWithChannelId:0 AndTitle:@"图片"];
    ActivityViewController *activityVc = [[ActivityViewController alloc]init];
    
    UINavigationController *zixunNavi = [[UINavigationController alloc]initWithRootViewController:zixunVC];
    UINavigationController *videoNavi = [[UINavigationController alloc]initWithRootViewController:videoVC];
    UINavigationController *imageNavi = [[UINavigationController alloc]initWithRootViewController:imageVC];
    UINavigationController *activityNavi = [[UINavigationController alloc]initWithRootViewController:activityVc];
    self.viewControllers =  @[zixunNavi,videoNavi,imageNavi,activityNavi];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
