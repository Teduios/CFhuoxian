//
//  VideoViewController.m
//  BaseProject
//
//  Created by tarena on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "VideoViewController.h"
#import "VideoLayout.h"
#import "VideoCell.h"
#import "VideoViewModel.h"
#import "ZiXunDetailViewController.h"

@interface VideoViewController ()<UICollectionViewDataSource,UICollectionViewDelegate>

@property (nonatomic,strong) UICollectionView *collectionview;
@property (nonatomic,strong) VideoViewModel *videoVM;

@end

@implementation VideoViewController

-(UICollectionView *)collectionview{
    if (!_collectionview) {
        _collectionview = [[UICollectionView alloc]initWithFrame:CGRectZero collectionViewLayout:[[VideoLayout alloc]init]];
        [self.view addSubview:_collectionview];
        [_collectionview mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        _collectionview.backgroundColor = [UIColor whiteColor];
        _collectionview.delegate = self;
        _collectionview.dataSource = self;
        [_collectionview registerClass:[VideoCell class] forCellWithReuseIdentifier:@"Cell"];
    }
    return _collectionview;
}

-(VideoViewModel *)videoVM{
    if (!_videoVM) {
        _videoVM = [[VideoViewModel alloc]init];
    }
    return _videoVM;
}

-(instancetype)init{
    if (self = [super init]) {
        self.title = @"视频";
        self.tabBarItem.image = [UIImage imageNamed:@"tabbar_item_my_music"];
        self.tabBarItem.selectedImage = [UIImage imageNamed:@"tabbar_item_my_music_selected"];
    }
    return self;
}

#pragma mark - UICollectionView
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.videoVM.rowNumber;
}
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    VideoCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"Cell" forIndexPath:indexPath] ;
    [cell.imageView.imageView setImageWithURL:[self.videoVM previewForRow:indexPath.row]];
    cell.titleLb.text = [self.videoVM nameForRow:indexPath.row];
    cell.statusLb.text = [self.videoVM statusForRow:indexPath.row];
    cell.viewersLb.text = [self.videoVM viewersForRow:indexPath.row];
    cell.nowLb.hidden = NO;
    cell.videoImg.hidden = NO;
    return cell;
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    [collectionView deselectItemAtIndexPath:indexPath animated:YES];
    ZiXunDetailViewController *vc = [[ZiXunDetailViewController alloc]initWithURL:[self.videoVM urlForRow:indexPath.row]];
    vc.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:vc animated:YES];
}
- (void)viewDidLoad {
    [super viewDidLoad];
   
    self.collectionview.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.videoVM getDataFromNetCompleteHandle:^(NSError *error) {
            [_collectionview reloadData];
            [_collectionview.header endRefreshing];
        }];
    }];
    [_collectionview.header beginRefreshing];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
