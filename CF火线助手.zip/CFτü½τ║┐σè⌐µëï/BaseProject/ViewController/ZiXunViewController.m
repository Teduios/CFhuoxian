//
//  ZiXunViewController.m
//  BaseProject
//
//  Created by tarena on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ZiXunViewController.h"
#import "iCarousel.h"
#import "ZiXunViewModel.h"
#import "ZiXunCell.h"
#import "ZiXunPicCell.h"
#import "ZiXunDetailViewController.h"

@interface ZiXunViewController ()<iCarouselDataSource,iCarouselDelegate,UITableViewDataSource,UITableViewDelegate>

@property (nonatomic,strong) UITableView *tableView;
@property (nonatomic,strong) ZiXunViewModel *zixunVM;

@end

@implementation ZiXunViewController

{
    iCarousel *_ic;
    UIPageControl *_pageControl;
    UILabel *_titleLb;
    NSTimer *_timer;
}
-(UIView *)headerView{
    [_timer invalidate];
    UIView *headView = [[UIView alloc]initWithFrame:CGRectMake(0,0, 0, kWindowW/kWindowH * 335)];
   
    UIView *bottomView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, kWindowW, 35)];
   
    [headView addSubview:bottomView];
    [bottomView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.mas_equalTo(0);
        make.height.mas_equalTo(50);
    }];
    _titleLb = [[UILabel alloc]init];
    _titleLb.font = [UIFont flatFontOfSize:15];
    _titleLb.textColor = [UIColor whiteColor];
    [bottomView addSubview:_titleLb];
    [_titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(-5);
        make.left.mas_equalTo(10);
    }];
    _titleLb.text = [self.zixunVM headertitleForRow:0];
    _pageControl = [UIPageControl new];
    _pageControl.numberOfPages = self.zixunVM.count;
    [bottomView addSubview:_pageControl];
    [_pageControl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(-10);
        make.bottom.mas_equalTo(5);
        make.width.mas_equalTo(65);
        make.left.mas_equalTo(_titleLb.mas_right).mas_equalTo(10);
    }];
    _pageControl.userInteractionEnabled = NO;
    _pageControl.pageIndicatorTintColor = [UIColor whiteColor];
    _pageControl.currentPageIndicatorTintColor = [UIColor redColor];
    
    _ic = [iCarousel new];
    [headView addSubview:_ic];
    [_ic mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.top.right.mas_equalTo(0);
        make.bottom.mas_equalTo(bottomView.mas_top).mas_equalTo(0);
    }];
    _ic.delegate = self;
    _ic.dataSource = self;
    _ic.pagingEnabled = YES;
    _ic.scrollSpeed = 1;
    _ic.type = 3;
    if (self.zixunVM.count > 0) {
        _timer = [NSTimer bk_scheduledTimerWithTimeInterval:3 block:^(NSTimer *timer) {
            [_ic scrollToItemAtIndex:_ic.currentItemIndex+1 animated:YES];
        } repeats:YES];
    }
    return headView;
}

-(instancetype)init{
    if (self = [super init]) {
        self.title = @"资讯";
        self.tabBarItem.image = [UIImage imageNamed:@"tabbar_item_store"];
        self.tabBarItem.selectedImage = [UIImage imageNamed:@"tabbar_item_store_selected"];
    }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
 
    self.tableView.backgroundColor = [UIColor blackColor];
    self.tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.zixunVM refreshDataCompletionHandle:^(NSError *error) {
            self.tableView.tableHeaderView = [self headerView];
            [_tableView.header endRefreshing];
            [_tableView reloadData];
        }];
    }];
    [_tableView.header beginRefreshing];
    self.tableView.footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        [self.zixunVM getMoreDataCompletionHandle:^(NSError *error) {
            [_tableView.footer endRefreshing];
            [_tableView reloadData];
            
        }];
    }];
    self.tableView.contentInset=UIEdgeInsetsMake(20, 0, 0, 0);
    
}
#pragma mark - iCrouse
- (NSInteger)numberOfItemsInCarousel:(iCarousel *)carousel{
    return self.zixunVM.count;
}
- (UIView *)carousel:(iCarousel *)carousel viewForItemAtIndex:(NSInteger)index reusingView:(UIView *)view{
    if (!view) {
        view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, kWindowW, kWindowW/kWindowH *335)];
        UIImageView *imgView = [UIImageView new];
        imgView.contentMode = 1;
        [view addSubview:imgView];
        imgView.tag = 100;
        imgView.contentMode = 2;
        view.clipsToBounds = YES;
        [imgView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
    }
    UIImageView *imgView = (UIImageView *)[view viewWithTag:100];
    [imgView setImageWithURL:[self.zixunVM headerimgForRow:index]];
    return view;
}
-(CGFloat)carousel:(iCarousel *)carousel valueForOption:(iCarouselOption)option withDefault:(CGFloat)value{
    if (option == iCarouselOptionWrap) {
        return YES;
    }
    if (option == iCarouselOptionShowBackfaces) {
        return NO;
    }

    return value;
}
-(void)carouselCurrentItemIndexDidChange:(iCarousel *)carousel{
    _titleLb.text = [self.zixunVM headertitleForRow:carousel.currentItemIndex];
    _pageControl.currentPage = carousel.currentItemIndex;
}

- (void)carousel:(iCarousel *)carousel didSelectItemAtIndex:(NSInteger)index{
    ZiXunDetailViewController *vc = [[ZiXunDetailViewController alloc]initWithURL:[self.zixunVM headUrlForRow:index]];
    vc.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:vc animated:YES];
}

-(ZiXunViewModel *)zixunVM{
    if (!_zixunVM) {
        _zixunVM = [ZiXunViewModel new];
    }
    return _zixunVM;
}

- (UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.tableFooterView = [UIView new];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        [self.view addSubview:_tableView];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        [_tableView registerClass:[ZiXunCell class] forCellReuseIdentifier:@"Cell"];
        [_tableView registerClass:[ZiXunPicCell class] forCellReuseIdentifier:@"PicCell"];
    }
    return _tableView;
}
#pragma mark - UITableView
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.zixunVM.rowNumber;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if ([self.zixunVM listImgUrlForRow:indexPath.row]) {
        ZiXunPicCell *cell = [tableView dequeueReusableCellWithIdentifier:@"PicCell"];
        cell.titleLb.text = [self.zixunVM titleForRow:indexPath.row];
        cell.dateLb.text = [self.zixunVM dateForRow:indexPath.row];
        NSArray *arr = [self.zixunVM listImgForRow:indexPath.row];
        [cell.imgView0 setImageWithURL:arr[0]];
        [cell.imgView1 setImageWithURL:arr[1]];
        [cell.imgview2 setImageWithURL:arr[2]];
        return cell;
    }else{
    ZiXunCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    [cell.imgView setImageWithURL:[self.zixunVM imgForrow:indexPath.row]];
    cell.titleLb.text = [self.zixunVM titleForRow:indexPath.row];
    cell.summaryLb.text = [self.zixunVM summaryRowRow:indexPath.row];
    cell.dateLb.text = [self.zixunVM dateForRow:indexPath.row];
    return cell;
    }
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    ZiXunDetailViewController *VC = [[ZiXunDetailViewController alloc]initWithURL:[self.zixunVM urlForRow:indexPath.row]];
    VC.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:VC animated:YES];
}
-(CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return UITableViewAutomaticDimension;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
