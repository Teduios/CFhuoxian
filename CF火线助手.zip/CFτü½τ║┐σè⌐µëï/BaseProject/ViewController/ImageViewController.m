//
//  ImageViewController.m
//  BaseProject
//
//  Created by tarena on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ImageViewController.h"
#import "ImgViewModel.h"
#import "PSCollectionView.h"
#import "ImgModel.h"
#import "ImgDetailViewController.h"
#import "CFImageView.h"
#import "FFNavbarMenu.h"
@interface ImageViewController () <UICollectionViewDelegate,PSCollectionViewDataSource,PSCollectionViewDelegate,FFNavbarMenuDelegate>
@property (nonatomic,strong) ImgViewModel *imgVM;
@property (nonatomic,strong) PSCollectionView *collectionView;
@property (strong, nonatomic) FFNavbarMenu *menu;
@end

@implementation ImageViewController
- (instancetype)initWithChannelId:(NSInteger)channelId AndTitle:(NSString *)myTitle{
    if (self = [super init]) {
        self.channelId = channelId;
        self.myTitle = myTitle;
        self.title = _myTitle;
        self.tabBarItem.image = [UIImage imageNamed:@"tabbar_item_selected"];
        self.tabBarItem.selectedImage = [UIImage imageNamed:@"tabbar_item_selected_selected"];
    }
    return self;
}
- (FFNavbarMenu *)menu {
    if (_menu == nil) {
        FFNavbarMenuItem *item1 = [FFNavbarMenuItem ItemWithTitle:@"红人" icon:[UIImage imageNamed:@"item1.png"]];
        FFNavbarMenuItem *item2 = [FFNavbarMenuItem ItemWithTitle:@"囧图" icon:[UIImage imageNamed:@"item2.png"]];
        FFNavbarMenuItem *item3 = [FFNavbarMenuItem ItemWithTitle:@"壁纸" icon:[UIImage imageNamed:@"item3.png"]];
        
        _menu = [[FFNavbarMenu alloc] initWithItems:@[item1,item2,item3] width:kWindowW maximumNumberInRow:3];
        _menu.backgroundColor = [UIColor blackColor];
        _menu.separatarColor = [UIColor lightGrayColor];
        _menu.textColor = [UIColor whiteColor];
        _menu.delegate = self;
    }
    return _menu;
}

- (ImgViewModel *)imgVM{
    if (!_imgVM) {
        _imgVM = [[ImgViewModel alloc]initWithChannelId:_channelId];
    }
    return _imgVM;
}
- (PSCollectionView *)collectionView{
    if (!_collectionView) {
        _collectionView = [PSCollectionView new];
        _collectionView.delegate = self;
        _collectionView.collectionViewDataSource = self;
        _collectionView.collectionViewDelegate = self;
        [self.view addSubview:_collectionView];
        [_collectionView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        _collectionView.numColsPortrait = 2;
        _collectionView.backgroundColor = kRGBColor(220, 221, 224);
    }
    return _collectionView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
 
    self.collectionView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
       [self.imgVM refreshDataCompletionHandle:^(NSError *error) {
           [self.collectionView reloadData];
           [self.collectionView.header endRefreshing];
       }];
    }];
    [self.collectionView.header beginRefreshing];
    self.collectionView.footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
       [self.imgVM getMoreDataCompletionHandle:^(NSError *error) {
           [self.collectionView reloadData];
           [self.collectionView.footer endRefreshing];
       }];
    }];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"更多" style:UIBarButtonItemStylePlain target:self action:@selector(openMenu:)];
    self.navigationItem.rightBarButtonItem.tintColor = [UIColor whiteColor];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark - PSCollectionViewDelegate
- (NSInteger)numberOfRowsInCollectionView:(PSCollectionView *)collectionView{
    return self.imgVM.rowNumber;
}
- (CGFloat)collectionView:(PSCollectionView *)collectionView heightForRowAtIndex:(NSInteger)index{
    ImgPicListModel *model = [self.imgVM.dataArr objectAtIndex:index];
    CGFloat width = model.img_width.floatValue;
    CGFloat height = model.img_height.floatValue;
    return (kWindowW/2-12) *height/width;
}
- (PSCollectionViewCell *)collectionView:(PSCollectionView *)collectionView cellForRowAtIndex:(NSInteger)index{
    PSCollectionViewCell *cell = [collectionView dequeueReusableViewForClass:[PSCollectionViewCell class]];
        if (!cell) {
            cell = [[PSCollectionViewCell alloc]initWithFrame:CGRectZero];
            cell.backgroundColor = [UIColor whiteColor];
            CFImageView *imageView = [CFImageView new];
            [cell addSubview:imageView];
            imageView.tag = 100;
            UILabel *label1 = [UILabel new];
            [cell addSubview:label1];
            [label1 mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.mas_equalTo(imageView.mas_bottom).mas_equalTo(5);
                make.left.mas_equalTo(5);
                make.right.mas_equalTo(-5);
            }];
            //label1.backgroundColor = [UIColor whiteColor];
            label1.font = [UIFont systemFontOfSize:15];
            label1.tag = 200;
            UILabel *label2 = [UILabel new];
            [imageView addSubview:label2];
            [label2 mas_makeConstraints:^(MASConstraintMaker *make) {
                make.right.bottom.mas_equalTo(0);
            }];
            label2.textAlignment = NSTextAlignmentCenter;
            label2.font = [UIFont boldFlatFontOfSize:15];
            label2.textColor = [UIColor whiteColor];
            label2.backgroundColor = [UIColor blackColor];
            label2.alpha = 0.75;
            label2.tag = 300;
        
        }
    CFImageView *iv = (CFImageView *)[cell viewWithTag:100];
    iv.frame = CGRectMake(0, 0, kWindowW/2-12, [self collectionView:collectionView heightForRowAtIndex:index]-45);
    [iv.imageView setImageWithURL:[self.imgVM iconURLForRow:index]];
    UILabel *label1 = (UILabel *)[cell viewWithTag:200];
    label1.text = [self.imgVM titleForRow:index];
    label1.numberOfLines = 2;
    UILabel *label2 = (UILabel *)[cell viewWithTag:300];
    label2.text = [self.imgVM descForRow:index];
    return cell;
}
- (void)collectionView:(PSCollectionView *)collectionView didSelectCell:(PSCollectionViewCell *)cell atIndex:(NSInteger)index{
    if ([self.imgVM isManHuaTypeForRow:index]) {
        [self showErrorMsg:@"抱歉，暂无漫画"];
    }
    else{
    ImgDetailViewController *vc = [[ImgDetailViewController alloc]initWithId:[self.imgVM imgIdForRow:index]];
    UINavigationController *navi = [[UINavigationController alloc]initWithRootViewController:vc];
    vc.hidesBottomBarWhenPushed = YES;
    [self.navigationController presentViewController:navi animated:YES completion:nil];
    }
}
#pragma mark - FFnaviDelegate
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    if (self.menu) {
        [self.menu dismissWithAnimation:NO];
    }
}

- (void)openMenu:(id)sender {
    self.navigationItem.rightBarButtonItem.enabled = NO;
    if (self.menu.isOpen) {
        [self.menu dismissWithAnimation:YES];
    } else {
        [self.menu showInNavigationController:self.navigationController];
    }
}

- (void)didShowMenu:(FFNavbarMenu *)menu {
    [self.navigationItem.rightBarButtonItem setTitle:@"隐藏"];
    self.navigationItem.rightBarButtonItem.enabled = YES;
}

- (void)didDismissMenu:(FFNavbarMenu *)menu {
    [self.navigationItem.rightBarButtonItem setTitle:@"更多"];
    self.navigationItem.rightBarButtonItem.enabled = YES;
}

- (void)didSelectedMenu:(FFNavbarMenu *)menu atIndex:(NSInteger)index {
    if (index == 0) {
        _channelId = 2;
        _myTitle = @"红人";
    }
    if (index == 1) {
        _channelId = 4;
        _myTitle = @"囧图";
    }
    if (index == 2) {
        _channelId = 5;
        _myTitle = @"壁纸";
    }
    ImageViewController *vc = [[ImageViewController alloc]initWithChannelId:_channelId AndTitle:_myTitle];
    [self.navigationController pushViewController:vc animated:YES];
}

- (UIStatusBarStyle)preferredStatusBarStyle {
    return UIStatusBarStyleLightContent;
}


- (void)willAnimateRotationToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration {
    self.menu = nil;
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
