//
//  ImgDetailViewController.m
//  BaseProject
//
//  Created by tarena on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ImgDetailViewController.h"
#import "ImgDetailViewModel.h"
#import "iCarousel.h"
#import "CFImageView.h"
#import "Factory.h"
@interface ImgDetailViewController () <iCarouselDataSource,iCarouselDelegate>
@property (nonatomic,strong) ImgDetailViewModel *imgDtVM;
@property (nonatomic,strong) iCarousel *ic;
@property (nonatomic) NSInteger currentIndex;
@end

@implementation ImgDetailViewController
- (instancetype)initWithId:(NSInteger)Id{
    if (self = [super init]) {
        self.Id = Id;
    }
    return self;
}
- (ImgDetailViewModel *)imgDtVM{
    if (!_imgDtVM) {
        _imgDtVM = [[ImgDetailViewModel alloc]initWithId:_Id];
    }
    return _imgDtVM;
}
- (iCarousel *)ic{
    if (!_ic) {
        _ic = [iCarousel new];
        _ic.delegate = self;
        _ic.dataSource = self;
        _ic.type = 0;
        _ic.autoscroll = 0;
        _ic.pagingEnabled = YES;
        _ic.scrollSpeed = 2;
        [self.view addSubview:_ic];
        [_ic mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.mas_equalTo(self.view);
            make.top.mas_equalTo(0);
            make.left.right.mas_equalTo(0);
        }];
        UIView *botomView = [UIView new];
        [_ic addSubview:botomView];
        [botomView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.height.mas_equalTo(45);
            make.left.right.bottom.mas_equalTo(0);
        }];
        botomView.backgroundColor = [UIColor blackColor];
        botomView.alpha = 0.75;
        UILabel *label1 = [UILabel new];
        [botomView addSubview:label1];
        [label1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.mas_equalTo(5);
            make.bottom.right.mas_equalTo(-5);
        }];
        label1.text = [self.imgDtVM descForRow:0];
        label1.textColor = [UIColor whiteColor];
        label1.font = [UIFont boldFlatFontOfSize:13];
        label1.numberOfLines = 0;
        label1.tag = 200;
        self.title = [NSString stringWithFormat:@"1/%ld",self.imgDtVM.rowNumber];
        }
    return _ic;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self.imgDtVM getDataFromNetCompleteHandle:^(NSError *error) {
        [self.ic reloadData];
    }];
    [Factory addOtherBackItemToVC:self];
    UIBarButtonItem *item = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"cell_download"] style:UIBarButtonItemStylePlain target:self action:@selector(downImg)];
    item.tintColor = [UIColor whiteColor];
    self.navigationItem.rightBarButtonItem = item;
}
- (void)downImg{
    NSURL *url = [self.imgDtVM iconURLForRow:_currentIndex];
    NSData *data = [NSData dataWithContentsOfURL:url];
    UIImage *image = [UIImage imageWithData:data];
    UIImageWriteToSavedPhotosAlbum(image, self, @selector(imageSavedToPhotosAlbum:didFinishSavingWithError:contextInfo:), nil);
}
- (void)imageSavedToPhotosAlbum:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo
{
    NSString *message = @"呵呵";
    [self showProgress];
    if (!error) {
        message = @"成功保存到相册";
        [self showSuccessMsg:message];
//        self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"wifibox_checkmark"] style:UIBarButtonItemStyleDone target:self action:nil];
//        self.navigationItem.rightBarButtonItem.tintColor = [UIColor whiteColor];
    }else
    {
        message = [error description];
        [self showErrorMsg:error];
    }
    
    NSLog(@"message is %@",message);
}
#pragma mark - iCarousel
//添加循环滚动
- (CGFloat)carousel:(iCarousel *)carousel valueForOption:(iCarouselOption)option withDefault:(CGFloat)value{
    if (option == iCarouselOptionWrap) {
        return YES;
    }
    //修改缝隙
    if (option == iCarouselOptionSpacing) {
        return value;
    }
    //取消后背的显示
    if (option == iCarouselOptionShowBackfaces) {
        return YES;
    }
    return value;
}
//问：有多少个cell
- (NSInteger)numberOfItemsInCarousel:(iCarousel *)carousel{
    return self.imgDtVM.rowNumber;
}
- (UIView *)carousel:(iCarousel *)carousel viewForItemAtIndex:(NSInteger)index reusingView:(UIView *)view{
    if (!view) {
        view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
        CFImageView *imageView = [CFImageView new];
        imageView.tag = 100;
        [view addSubview:imageView];
        [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
    }
    CFImageView *imageView = (CFImageView *)[view viewWithTag:100];
    [imageView.imageView setImageWithURL:[self.imgDtVM iconURLForRow:index]];
    return view;
}
- (void)carouselCurrentItemIndexDidChange:(iCarousel *)carousel{
    _currentIndex = carousel.currentItemIndex;
    UILabel *label1 = (UILabel *)[self.view viewWithTag:200];
    label1.text = [self.imgDtVM descForRow:carousel.currentItemIndex];
    self.title = [NSString stringWithFormat:@"%ld/%ld",carousel.currentItemIndex+1,self.imgDtVM.rowNumber];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
