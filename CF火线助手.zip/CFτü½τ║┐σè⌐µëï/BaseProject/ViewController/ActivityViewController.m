//
//  ActivityViewController.m
//  BaseProject
//
//  Created by tarena on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ActivityViewController.h"
#import "ActivityViewModel.h"
#import "ActivityOneCell.h"
#import "ZiXunDetailViewController.h"

@interface ActivityViewController ()<UITableViewDataSource,UITableViewDelegate>

@property (nonatomic,strong) ActivityViewModel *activityVM;
@property (nonatomic,strong) UITableView *tableView;

@end

@implementation ActivityViewController

-(ActivityViewModel *)activityVM{
    if (!_activityVM) {
        _activityVM = [[ActivityViewModel alloc]init];
    }
    return _activityVM;
}
-(UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        [self.view addSubview:_tableView];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        [_tableView registerClass:[ActivityOneCell class] forCellReuseIdentifier:@"Cell"];
    }
    return _tableView;
}

-(instancetype)init{
    if (self = [super init]) {
        self.title = @"活动";
        self.tabBarItem.image = [UIImage imageNamed:@"tabbar_item_more"];
        self.tabBarItem.selectedImage = [UIImage imageNamed:@"tabbar_item_more_selected"];
    }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    self.tableView.backgroundColor = [UIColor blackColor];
    self.tableView.header = [MJRefreshNormalHeader  headerWithRefreshingBlock:^{
        [self.activityVM refreshDataCompletionHandle:^(NSError *error) {
            [_tableView reloadData];
            [_tableView.header endRefreshing];
        }];
    }];
    [_tableView.header beginRefreshing];
    
    self.tableView.footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        [self.activityVM getMoreDataCompletionHandle:^(NSError *error) {
            [_tableView reloadData];
            [_tableView.footer endRefreshing];
        }];
    }];
    // Do any additional setup after loading the view.
}

#pragma mark - UITableview
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.activityVM.rowNumber;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    ActivityOneCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    [cell.imgView.imageView setImageWithURL:[self.activityVM imgURLForRow:indexPath.row]];
    cell.titleLb.text = [self.activityVM titleForRow:indexPath.row];
    cell.summaryLb.text = [self.activityVM summaryForRow:indexPath.row];
    cell.dateLb.text = [self.activityVM dateForRow:indexPath.row];
    NSString *str = [self.activityVM subscriptForRow:indexPath.row];
    if ([str isEqualToString:@"手机"]) {
        cell.joinLb.text = [NSString stringWithFormat:@"%@参与",str];
        cell.joinLb.backgroundColor = kRGBColor(30, 150, 250);
    }else if ([str isEqualToString:@"官网"]){
        cell.joinLb.text = [NSString stringWithFormat:@"%@参与",str];
        cell.joinLb.backgroundColor = kRGBColor(27, 200, 220);
    }
    if ([self.activityVM pcreedForRow:indexPath.row]) {
        cell.nowLb.text = @"已结束";
        cell.nowLb.textColor = [UIColor lightGrayColor];
        cell.progress.progress = 1.0;
        
    }else {
        cell.nowLb.text = @"进行中";
        cell.nowLb.textColor = kRGBColor(224, 71, 37);
        cell.progress.progress = [self.activityVM valueForRow:indexPath.row];
    }
    
    cell.giftLb.hidden = NO;
    cell.lineView.hidden = NO;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    ZiXunDetailViewController *vc = [[ZiXunDetailViewController alloc]initWithURL:[self.activityVM urlForRow:indexPath.row]];
    vc.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:vc animated:YES];
    
}
-(CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return UITableViewAutomaticDimension;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
