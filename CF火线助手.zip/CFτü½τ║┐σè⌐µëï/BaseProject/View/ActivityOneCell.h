//
//  ActivityOneCell.h
//  BaseProject
//
//  Created by tarena on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CFImageView.h"

@interface ActivityOneCell : UITableViewCell

@property (nonatomic,strong)UIView *view;
@property (nonatomic,strong)UIView *lineView;
@property (nonatomic,strong)CFImageView *imgView;
@property (nonatomic,strong)UILabel *titleLb;
@property (nonatomic,strong)UILabel *giftLb;
@property (nonatomic,strong)UILabel *summaryLb;

@property (nonatomic,strong)UILabel *nowLb;
@property (nonatomic,strong)UILabel *dateLb;

@property (nonatomic,strong)UIProgressView *progress;
@property (nonatomic,strong)UILabel *joinLb;

@end
