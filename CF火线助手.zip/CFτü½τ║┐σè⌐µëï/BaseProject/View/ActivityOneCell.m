//
//  ActivityOneCell.m
//  BaseProject
//
//  Created by tarena on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ActivityOneCell.h"

@implementation ActivityOneCell

-(UIView *)view{
    if (!_view) {
        _view = [[UIView alloc]init];
        _view.layer.cornerRadius = 5;
        _view.backgroundColor = [UIColor whiteColor];
        [self.contentView addSubview:_view];
        [_view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.mas_equalTo(10);
            make.right.mas_equalTo(-10);
            make.bottom.mas_equalTo(0);
        }];
    }
    return _view;
}

-(CFImageView *)imgView{
    if (!_imgView) {
        _imgView = [CFImageView new];
        [self.view addSubview:_imgView];
        [_imgView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.mas_equalTo(10);
            make.size.mas_equalTo(CGSizeMake(105, 65));
            
        }];
    }
    return _imgView;
}
-(UILabel *)titleLb{
    if (!_titleLb) {
        _titleLb = [UILabel new];
        _titleLb.numberOfLines = 0;
        _titleLb.font = [UIFont systemFontOfSize:15];
        [self.view addSubview:_titleLb];
        [_titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.topMargin.mas_equalTo(self.imgView.mas_topMargin);
            make.left.mas_equalTo(self.imgView.mas_right).mas_equalTo(10);
            make.right.mas_equalTo(0);
        }];
    }
    return _titleLb;
}
-(UILabel *)giftLb{
    if (!_giftLb) {
        _giftLb = [UILabel new];
        _giftLb.font = [UIFont systemFontOfSize:12];
        _giftLb.text = @"相关礼品:";
        [self.view addSubview:_giftLb];
        [_giftLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leftMargin.mas_equalTo(self.titleLb.mas_leftMargin);
            make.bottomMargin.mas_equalTo(self.imgView.mas_bottomMargin);
            
        }];
    }
    return _giftLb;
}
-(UILabel *)summaryLb{
    if (!_summaryLb) {
        _summaryLb = [UILabel new];
        _summaryLb.font = [UIFont systemFontOfSize:12];
        _summaryLb.textColor = kRGBColor(203, 85, 49);
        [self.view addSubview:_summaryLb];
        [_summaryLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.giftLb.mas_right);
            make.bottomMargin.mas_equalTo(self.giftLb.mas_bottomMargin);
        }];
    }
    return _summaryLb;
}
-(UIView *)lineView{
    if (!_lineView) {
        _lineView = [UIView new];
        _lineView.backgroundColor = [UIColor lightGrayColor];
        [self.view addSubview:_lineView];
        [_lineView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leftMargin.mas_equalTo(self.imgView.mas_leftMargin);
            make.top.mas_equalTo(self.imgView.mas_bottom).mas_equalTo(10);
            make.right.mas_equalTo(-10);
            make.height.mas_equalTo(0.5);
        }];
    }
    return _lineView;
}

-(UILabel *)nowLb{
    if (!_nowLb) {
        _nowLb = [UILabel new];
        _nowLb.font = [UIFont systemFontOfSize:12];
        [self.view addSubview:_nowLb];
        [_nowLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leftMargin.mas_equalTo(self.lineView.mas_leftMargin);
            make.top.mas_equalTo(self.lineView.mas_bottom).mas_equalTo(15);
        }];
    }
    return _nowLb;
}
-(UILabel *)dateLb{
    if (!_dateLb) {
        _dateLb = [UILabel new];
        _dateLb.font = [UIFont systemFontOfSize:12];
        [self.view addSubview:_dateLb];
        [_dateLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.nowLb.mas_right);
            make.topMargin.mas_equalTo(self.nowLb.mas_topMargin);
        }];
    }
    return _dateLb;
}

-(UIProgressView *)progress{
    if (!_progress) {
        _progress = [[UIProgressView alloc]initWithProgressViewStyle:UIProgressViewStyleBar];
        _progress.progressTintColor = [UIColor lightGrayColor];
        _progress.trackTintColor =  kRGBColor(224, 71, 37);
        [self.view addSubview:_progress];
        [_progress mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leftMargin.mas_equalTo(self.imgView.mas_leftMargin);
            make.top.mas_equalTo(self.nowLb.mas_bottom).mas_equalTo(10);
            make.bottom.mas_equalTo(-10);
            make.width.mas_equalTo(180);
        }];
    }
    return _progress;
}
-(UILabel *)joinLb{
    if (!_joinLb) {
        _joinLb = [UILabel new];
        _joinLb.font = [UIFont systemFontOfSize:12];
        _joinLb.textColor = [UIColor whiteColor];
        [self.view addSubview:_joinLb];
        [_joinLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(0);
            make.bottomMargin.mas_equalTo(self.progress.mas_bottomMargin);
        }];
    }
    return _joinLb;
}


-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.contentView.backgroundColor = [UIColor blackColor];
        
    }
    return self;
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
