//
//  ZiXunPicCell.m
//  BaseProject
//
//  Created by tarena on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ZiXunPicCell.h"

#define kImgW (kWindowW - 4 *10)/3
@implementation ZiXunPicCell

-(UIView *)view{
    if (!_view) {
        _view = [[UIView alloc]init];
        _view.backgroundColor = [UIColor whiteColor];
        _view.layer.cornerRadius = 5;
        [self.contentView addSubview:_view];
        [_view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.mas_equalTo(8);
            make.right.mas_equalTo(-8);
            make.height.mas_equalTo(133);
            make.bottom.mas_equalTo(0);
        }];
    }
    return _view;
}
-(UILabel *)titleLb{
    if (!_titleLb) {
        _titleLb = [UILabel new];
        [self.view addSubview:_titleLb];
        [_titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(10);
            make.left.mas_equalTo(10);
        }];
    }
    return _titleLb;
}
-(UILabel *)dateLb{
    if (!_dateLb) {
        _dateLb = [UILabel new];
        _dateLb.font = [UIFont systemFontOfSize:15];
        _dateLb.textColor = [UIColor lightGrayColor];
        [self.view addSubview:_dateLb];
        [_dateLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottomMargin.mas_equalTo(self.titleLb.mas_bottomMargin);
            make.right.mas_equalTo(-10);
        }];
    }
    return _dateLb;
}

-(UIImageView *)imgView0{
    if (!_imgView0) {
        _imgView0 = [[UIImageView alloc]init];
        _imgView0.contentMode = 2;
        _imgView0.clipsToBounds = YES;
        [self.view addSubview:_imgView0];
        [_imgView0 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leftMargin.mas_equalTo(self.titleLb.mas_leftMargin);
            make.top.mas_equalTo(self.titleLb.mas_bottom).mas_equalTo(10);
            make.size.mas_equalTo(CGSizeMake(kImgW, 77));
            make.bottom.mas_equalTo(-15);
        }];
    }
    return _imgView0;
}
-(UIImageView *)imgView1{
    if (!_imgView1) {
        _imgView1 = [[UIImageView alloc]init];
        _imgView1.contentMode = 2;
        _imgView1.clipsToBounds = YES;
        [self.view addSubview:_imgView1];
        [_imgView1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(self.imgView0);
            make.topMargin.mas_equalTo(self.imgView0.mas_topMargin);
            make.left.mas_equalTo(self.imgView0.mas_right).mas_equalTo(10);
        }];
    }
    return _imgView1;
}
-(UIImageView *)imgview2{
    if (!_imgview2) {
        _imgview2 = [UIImageView new];
        _imgview2.contentMode = 2;
        _imgview2.clipsToBounds = YES;
        [self.view addSubview:_imgview2];
        [_imgview2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(self.imgView0);
            make.topMargin.mas_equalTo(self.imgView0.mas_topMargin);
            make.left.mas_equalTo(self.imgView1.mas_right).mas_equalTo(10);
            make.right.mas_equalTo(-10);
        }];
    }
    return _imgview2;
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.contentView.backgroundColor = [UIColor blackColor];
    }
    return self;
}


- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
