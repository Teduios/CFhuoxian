//
//  VideoLayout.m
//  BaseProject
//
//  Created by tarena on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "VideoLayout.h"

#define kImgW (kWindowW-3*10)/2

@implementation VideoLayout

-(instancetype)init{
    if(self = [super init]){
        self.itemSize = CGSizeMake(kImgW,kImgW/170*165);
        self.minimumInteritemSpacing = 5;
        self.minimumLineSpacing = 0;
        self.sectionInset = UIEdgeInsetsMake(5, 5, 5, 5);
        
    }
    return self;
}

@end
