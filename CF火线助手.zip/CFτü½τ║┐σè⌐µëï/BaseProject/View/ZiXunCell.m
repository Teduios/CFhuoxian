//
//  ZiXunCell.m
//  BaseProject
//
//  Created by tarena on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ZiXunCell.h"

@implementation ZiXunCell

-(UIView *)view{
    if (!_view) {
        _view = [[UIView alloc]init];
        _view.backgroundColor = [UIColor whiteColor];
        _view.layer.cornerRadius = 5;
        [self.contentView addSubview:_view];
        [_view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.mas_equalTo(8);
            make.right.mas_equalTo(-8);
            make.height.mas_equalTo(85);
            make.bottom.mas_equalTo(0);
        }];
    }
    return _view;
}

-(UIImageView *)imgView{
    if (!_imgView) {
        _imgView = [[UIImageView alloc]init];
        _imgView.contentMode = 2;
        _imgView.clipsToBounds = YES;
        [self.view addSubview:_imgView];
        [_imgView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.mas_equalTo(10);
            make.size.mas_equalTo(CGSizeMake(90, 65));
            make.bottom.mas_equalTo(-10);
        }];
    }
    return _imgView;
}
-(UILabel *)titleLb{
    if (!_titleLb) {
        _titleLb = [UILabel new];
        [self.view addSubview:_titleLb];
        [_titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.imgView.mas_right).mas_equalTo(10);
            make.topMargin.mas_equalTo(self.imgView.mas_topMargin);
            make.right.mas_equalTo(-5);
        }];
    }
    return _titleLb;
}
-(UILabel *)summaryLb{
    if (!_summaryLb) {
        _summaryLb = [UILabel new];
        _summaryLb.textColor = [UIColor lightGrayColor];
        _summaryLb.font = [UIFont systemFontOfSize:15];
        _summaryLb.numberOfLines = 0;
        [self.view addSubview:_summaryLb];
        [_summaryLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.titleLb.mas_bottom).mas_equalTo(5);
            make.leftMargin.mas_equalTo(self.titleLb.mas_leftMargin);
            make.rightMargin.mas_equalTo(self.titleLb.mas_rightMargin);
        }];
    }
    return _summaryLb;
}
-(UILabel *)dateLb{
    if (!_dateLb) {
        _dateLb = [UILabel new];
        _dateLb.textColor = [UIColor lightGrayColor];
        _dateLb.font = [UIFont systemFontOfSize:15];
        [self.view addSubview:_dateLb];
        [_dateLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.rightMargin.mas_equalTo(self.titleLb.mas_rightMargin);
            make.bottomMargin.mas_equalTo(self.imgView.mas_bottomMargin);
            make.width.mas_equalTo(45);
        }];
    }
    return _dateLb;
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.contentView.backgroundColor = [UIColor blackColor];
    }
    return self;
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
