//
//  CFImageView.m
//  BaseProject
//
//  Created by tarena on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "CFImageView.h"

@implementation CFImageView

-(instancetype)init{
    if (self = [super init]) {
        _imageView = [UIImageView new];
        [self addSubview:_imageView];
        [_imageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        _imageView.contentMode = 2;
        _imageView.clipsToBounds = YES;
    }
    return self;
}

@end
