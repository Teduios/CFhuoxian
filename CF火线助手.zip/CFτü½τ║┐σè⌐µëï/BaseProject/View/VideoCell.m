//
//  VideoCell.m
//  BaseProject
//
//  Created by tarena on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "VideoCell.h"



@implementation VideoCell

-(UILabel *)nowLb{
    if (!_nowLb) {
        _nowLb = [UILabel new];
        _nowLb.text = @"正在直播";
        _nowLb.font = [UIFont systemFontOfSize:12];
        _nowLb.textColor = kRGBColor(207, 123, 104);
        [self.contentView addSubview:_nowLb];
        [_nowLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leftMargin.mas_equalTo(self.imageView.mas_leftMargin);
            make.bottomMargin.mas_equalTo(self.viewersLb.mas_bottomMargin);
            make.topMargin.mas_equalTo(self.viewersLb.mas_topMargin);
        }];

    }
    return _nowLb;
}

-(CFImageView *)imageView{
    if (!_imageView) {
        _imageView = [[CFImageView alloc]init];
        [self.contentView addSubview:_imageView];
        [_imageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.right.mas_equalTo(0);
            make.height.mas_equalTo(100);
        }];
        CFImageView *imgView = [[CFImageView alloc]init];
        
        imgView.imageView.image = [UIImage imageNamed:@"sound_playbtn"];
        [_imageView addSubview:imgView];
        [imgView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.center.mas_equalTo(0);
            make.size.mas_equalTo(CGSizeMake(40, 40));
        }];
    }
    return _imageView;
}

-(UILabel *)titleLb{
    if (!_titleLb) {
        _titleLb = [UILabel new];
        UIView *view = [[UIView alloc]init];
        view.backgroundColor = [UIColor blackColor];
        view.alpha = 0.5;
        [self.imageView addSubview:view];
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.bottom.mas_equalTo(0);
            make.height.mas_equalTo(20);
        }];
        [view addSubview:_titleLb];
        [_titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(10);
            make.centerY.mas_equalTo(0);
        }];
        _titleLb.font = [UIFont systemFontOfSize:13];
        _titleLb.textColor = [UIColor whiteColor];
    }
    return _titleLb;
}
-(UILabel *)statusLb{
    if (!_statusLb) {
        _statusLb = [UILabel new];
        
        _statusLb.numberOfLines = 2;
        _statusLb.font = [UIFont systemFontOfSize:13];
        [self.contentView addSubview:_statusLb];
        [_statusLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leftMargin.mas_equalTo(self.imageView.mas_leftMargin);
            make.top.mas_equalTo(self.imageView.mas_bottom).mas_equalTo(5);
            make.rightMargin.mas_equalTo(self.imageView.mas_rightMargin);
            make.bottom.mas_equalTo(self.viewersLb.mas_top).mas_equalTo(-5);
        }];
    }
    return _statusLb;
}

-(UILabel *)viewersLb{
    if (!_viewersLb) {
        _viewersLb = [UILabel new];
        _viewersLb.font = [UIFont systemFontOfSize:13];
        _viewersLb.textColor = [UIColor lightGrayColor];
        [self.contentView addSubview:_viewersLb];
        [_viewersLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.rightMargin.mas_equalTo(self.imageView.mas_rightMargin);
            make.bottom.mas_equalTo(-5);
        }];
    }
    return _viewersLb;
}

-(CFImageView *)videoImg{
    if (!_videoImg) {
        _videoImg = [CFImageView new];
        _videoImg.imageView.image = [UIImage imageNamed:@"o_dianying"];
        [self.contentView addSubview:_videoImg];
        [_videoImg mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(self.viewersLb.mas_left).mas_equalTo(-3);
            make.centerY.mas_equalTo(self.viewersLb);
            make.size.mas_equalTo(CGSizeMake(20, 20));
        }];
    }
    return _videoImg;
}

-(instancetype)init{
    if (self = [super init]) {
        
    }
    return self;
}

@end
