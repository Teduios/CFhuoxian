//
//  ZiXunCell.h
//  BaseProject
//
//  Created by tarena on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZiXunCell : UITableViewCell

@property (nonatomic,strong)UIView *view;
@property (nonatomic,strong)UIImageView *imgView;
@property (nonatomic,strong)UILabel *titleLb;
@property (nonatomic,strong)UILabel *summaryLb;
@property (nonatomic,strong)UILabel *dateLb;

@end
